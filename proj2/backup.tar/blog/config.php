<?php

$db_config['user'] = 'YourUserName';
$db_config['pass'] = 'YourPassword';

$blog_config['title'] = "YourTitle";
$blog_config['encrypt_key'] = 'YourPostEncryptionKey';

$env_config['root_path'] = '/blog';
